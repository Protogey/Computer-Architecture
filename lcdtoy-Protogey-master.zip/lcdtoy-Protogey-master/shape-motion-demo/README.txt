In this project shape-motion-demo was modified to do lab3.

Help was received from Justin - taught me how to stop a buzzer, and debug the
player scores.

Welcome to PONG! Pong is a 2 player game where players are faced in opposite
directions and must use their "paddles" to deflect the ball to enemy
boundaries. if the ball touches the end line, a point is rewared to the player
on the opposite end of the wall, and the ball is reset.

