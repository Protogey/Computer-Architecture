#include "states.h"

int statess(int i, int hold){
  switch(i){
  case 0:
    hold += 2;
    return hold;
  case 1:
    hold -= 2;
    return hold;
  case 2:
    hold += 2;
    return hold;
  case 3:
    hold -= 2;
    return hold;
  default:
    return hold;
  }
}
