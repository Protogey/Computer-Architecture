#ifndef states
#define states

int statess(int i, int hold);

#endif
