#ifndef lcdtypes_included
#define lcdtypes_included

typedef unsigned char u_char;
typedef unsigned int u_int;

#endif // lcdtypes_included
