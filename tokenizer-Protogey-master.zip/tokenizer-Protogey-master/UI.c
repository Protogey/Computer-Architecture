#include <stdio.h>
#include <string.h>
#include"tokenizer.h"
#define MAXLINE 1000
int main(){
  char UI[MAXLINE];
  char* point;
  printf("input q when finished with inputs \n");
  /*List *ll  init_history();*/
  while(UI[0] != 'q'){
    point = UI;
    printf("$");
    fgets(UI, MAXLINE, stdin);
    printf(UI,"\n");
    printf("string length: %i \n", string_length(point));
    printf("is valid character, 0 for no, 1 for yes: %c \n", is_valid_character(UI[0]));
    printf("start word: %s \n", find_word_start(point));
    printf("number of words is: %i \n", count_words(point));
    printf("end word is: %s \n", find_word_end(point));
    printf("tokens builder: ", tokenize(point));
  }
}

/*THE CODE COMMENTED OUT IS NOT MY CODE, THIS CODE WAS GIVEN BY PROFESSOR FREUDENTHAL AND WAS USED TO TEST, I DO NOT TAKE 
CREDIT FOR THIS CODE AS IT IS NOT MINE*/
/*
void add_history(List* list, char* str){
  int len;
  char* copy;
  Item* i;
  for(len = 0; str[len]; len++)
    ;
  for(len = 0; s[len]; len++)
    copy[len] = s[len];
  copy[len] = 0;

  i = (Item *)malloc(sizeof(Item));
  i->str = copy;
  i->next = 0;
  if(list->last){
    list->last->next = i;
  }
  else{
    list->first = i;
  }
}

void print_history(List* list){
  Item *p;
  int count = 1;
  printf("contents are: \n");
  for(p = list->first; p; p = p->next){
    printf("%i: <%s>\n", count, ip->str);
  }
}

List* init_history(){
  List *l = (List *)malloc(sizeof(List));
  l->first = l->last = 0;
  return l;
}
*/

/*The way tokenize is supposed to work is by counting the amount of words first, next we use a for loop to iterate
through all the words in the array, we check for valid characters until we cannot anymore, once we cannot anymore, we 
use a for loop to iterate the amount of valid characters and place those into a 2d array. next counter is updated to continue
the 2d array, after we return the 2d array. THIS METHOD DID NOT WORK BECAUSE IM DUMB AND DONT KNOW HOW TO USE POINTERS.*/
char** tokenize(char* str){
  int i = count_words(str);
  char tokenz[i][MAXLINE];
  int counter = 0;
  for(int x = 0; x<i; i--, x++){
    while(is_valid_character(str[counter]) == '1'){
      counter++;
    }
    for(int j = 0; j<counter; j++){
      tokenz[x][j] = str[j];
    }
    counter++;
    printf("%s", tokenz[i]);
  }
  char *p [i][MAXLINE];
  char **p2 [i][MAXLINE];
  *p = tokenz;
  **p2 = &p;
  return **p2;
}

/*Two counters are initialized, and used for this method, the first counter
iterates through our string, while the second(counter2) is used to count the words, only counts when we have spaces
because it shows how many words we have.*/
int count_words(char* str){
  int counter = 0;
  int counter2 = 0;
  while(str[counter] != '\0'){
    if(is_valid_character(str[counter])=='1'){
      counter++;
    }
    else{
    counter2++;
    counter++;
    }
  }
  return counter2;
}

/*Find word start uses a while loop that iterates until we have a valid character as the first character,
after iterating we return where it is a valid starting word.*/
char* find_word_start(char* str){
  int count = 0;
  while(is_valid_character(str[count]) == '0'){
    count++;
  }
  return &str[count];
}

/*Find end word uses a backwards for loop that stops at the first space starting backwards.
Once that space is found, we return the location where the space is and it returns the last word.*/
char* find_word_end(char* str){
  for(int i = string_length(str)-1;i>=0;i--){
    if(is_valid_character(str[i])=='0'){
      return &str[i];
      }
  }
  return str;
}

/*is valid character checks for newline, tab, and space, if the character is one of those, 
we return 0, if not we return 1.*/
char is_valid_character(char c){
  if(c == ' ' || c == '\n' || c == '\t'){
    return '0';
  }
  return '1';
}

/*string length counts spaces as characters, I was not sure if we should count spaces, but can be changed if needed to.
uses a while loop to make sure we do not reach null, and once we do, we return counter - 1 because it counts the first
character as 0.*/
int string_length(char* str){
  int count = 0;
  while(str[count] != '\0'){
     count++;
  }
  return (count-1);
}
