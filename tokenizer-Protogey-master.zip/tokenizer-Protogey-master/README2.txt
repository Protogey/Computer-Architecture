This assignment was prepared in a manner consistent with the instructor’s requirements

I received help from Jaime with the find word end method, he explained to me that I should use 
the other methods that I had already created(is_valid_character) to make my life easier and how to return a char pointer

I brainstormed with Justin to find a way to solve the tokenize method that we had to make. 

This Lab included 3 files; tokenize.h, history.h, and tester.c. I created UI.c for the first part of lab 1 and ended 
up doing the assignemnt in that file. 

For history I used the Linked list code that was given by professor Freudenthal to keep history and test my code, I do
not take credit for the code that I used, thats why it is commented out. 

I did not finish the tokenizer method because I was unsure on how to return a double pointer character
and understand that help was available to me, that was my fault.

Memory allocation was also not done because I was unsure in which portion to do it, and also how to do it.
