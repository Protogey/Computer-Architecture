#include <msp430.h>
#include "led.h"
#include "buzzer.h"
#include "libTimer.h"
#include "options.h"

void option_1(){
  configureClocks();
  int speed = 100;
  led_init();
  enableWDTInterrupts();
  
  buzzer_init();
  buzzer_set_period(10000);
}

void option_2(){
  configureClocks();
  int speed = 50;
  led_init();
  enableWDTInterrupts();
 
  buzzer_init();
  buzzer_set_period(12500);
}

void option_3(){
  configureClocks();
  int speed = 25;
  enableWDTInterrupts();
 
  buzzer_init();
  buzzer_set_period(15000);
}

void option_4(){
  configureClocks();
  int speed = 5;
  enableWDTInterrupts();
 
  buzzer_init();
  buzzer_set_period(17500);
}

void option_5(){
  configureClocks();
  buzzer_init();
  buzzer_set_period(5000);
}
