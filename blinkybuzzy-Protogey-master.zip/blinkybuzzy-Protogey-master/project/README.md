I received help from Jaime in understanding how to use the buttons on the decond board. I was lost and he told me that I had to
replace the 1's on the code with 2's. 

My project makes noises when a button is pushed and the lights turn on. 
