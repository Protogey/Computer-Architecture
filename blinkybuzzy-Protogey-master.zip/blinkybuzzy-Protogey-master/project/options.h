#ifndef options_included
#define options_included

void option_1();
void option_2();
void option_3();
void option_4();

#endif
