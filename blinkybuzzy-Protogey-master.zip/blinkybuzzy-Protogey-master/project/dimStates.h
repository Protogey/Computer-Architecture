#ifndef dimStates_included
#define dimStates_included



void sm_fast_clock();
void sm_slow_clock();
void sm_update_led();

#endif 
