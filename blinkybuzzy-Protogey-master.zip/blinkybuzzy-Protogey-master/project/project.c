#include <msp430.h>
#include "libTimer.h"
#include "switches.h"

void main(void)
{
  configureClocks();
  switch_init();
 
}
